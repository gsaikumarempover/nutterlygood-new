<?php

include_once GREENPATH_CORE_CPT_PATH . '/clients/shortcodes/clients-list/variations/image-only/hover-animations/fade-in/helper.php';
