<a itemprop="url" class="qodef-m-opener" href="<?php echo esc_url( wc_get_cart_url() ); ?>">
	<span class="qodef-m-opener-icon">
		<svg id="cart-icon" xmlns="http://www.w3.org/2000/svg" width="19.65" height="21.224" viewBox="0 0 19.65 21.224">
		  <path id="Path_1277" data-name="Path 1277"
		        d="M1762.1,1077.5a1,1,0,0,0-1,1v5.184a1.18,1.18,0,0,1-1.178,1.177h-9.971a1.18,1.18,0,0,1-1.178-1.177v-8.2a1,1,0,0,0-.551-.894l-3.327-1.662a1,1,0,0,0-1.339.449.987.987,0,0,0-.054.763,1,1,0,0,0,.5.579l2.77,1.384v7.577a3.18,3.18,0,0,0,3.177,3.177h9.971a3.181,3.181,0,0,0,3.178-3.177V1078.5A1,1,0,0,0,1762.1,1077.5Z"
		        transform="translate(-1743.452 -1072.831)" fill="#2453d4"/>
		  <path id="Path_1278" data-name="Path 1278"
		        d="M1751.156,1088.244a2.906,2.906,0,1,0,2.906,2.9A2.908,2.908,0,0,0,1751.156,1088.244Zm0,3.811a.906.906,0,1,1,.906-.907A.907.907,0,0,1,1751.156,1092.055Z"
		        transform="translate(-1743.452 -1072.831)" fill="#2453d4"/>
		  <path id="Path_1279" data-name="Path 1279"
		        d="M1759.981,1088.244a2.906,2.906,0,1,0,2.906,2.9A2.908,2.908,0,0,0,1759.981,1088.244Zm0,3.811a.906.906,0,1,1,.906-.907A.907.907,0,0,1,1759.981,1092.055Z"
		        transform="translate(-1743.452 -1072.831)" fill="#2453d4"/>
		</svg>
	</span>
	<span class="qodef-m-opener-count"><?php echo WC()->cart->cart_contents_count; ?></span>
</a>
